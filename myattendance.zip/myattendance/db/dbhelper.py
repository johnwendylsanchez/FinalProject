from sqlite3 import connect,Row

database:str = 'db/school.db'

def getprocess(sql:str,vals:list)->list:
    conn:any = connect(database)
    conn.row_factory = Row
    cursor:any = conn.cursor()
    cursor.execute(sql,vals)
    data:list = cursor.fetchall()
    cursor.close()
    conn.close()
    return data

def postprocess(sql:str,vals:list)->bool:
    try:
        conn:any = connect(database)
        cursor:any = conn.cursor()
        cursor.execute(sql,vals)
        conn.commit()
    except Exception as e:
        print(f"Error : {e}")
    finally:
        cursor.close()
        conn.close()
        return True if cursor.rowcount>0 else False
    
    
def getall(table:str)->list:
    sql:str = f"SELECT * FROM `{table}`"
    return getprocess(sql,[]) 

def getrecord(table:str,**kwargs)->list:
    keys:list = list(kwargs.keys())
    vals:list = list(kwargs.values())
    flds:list = []
    for key in keys:
        flds.append(f"`{key}`=?")
    fields:str = " AND ".join(flds)
    sql:str = f"SELECT * FROM `{table}` WHERE {fields}"
    return getprocess(sql,vals)
    
def addrecord(table:str, **kwargs) -> bool:
    keys = list(kwargs.keys())
    vals = list(kwargs.values())
    placeholders = ",".join(["?"] * len(keys))  
    fields = "`,`".join(keys)
    sql = f"INSERT INTO `{table}`(`{fields}`) VALUES ({placeholders})"  
    return postprocess(sql, vals)


def deleterecord(table:str, **kwargs) -> bool:
    keys = list(kwargs.keys())
    vals = list(kwargs.values())
    conditions = " AND ".join([f"`{k}`=?" for k in keys])
    sql = f"DELETE FROM `{table}` WHERE {conditions}"  
    return postprocess(sql, vals)


def updaterecord(table:str, **kwargs) -> bool:
    keys = list(kwargs.keys())
    vals = list(kwargs.values())

    id_field = keys[0]
    id_value = vals[0]
    fields = ", ".join([f"`{k}`=?" for k in keys[1:]])
    sql = f"UPDATE `{table}` SET {fields} WHERE `{id_field}`=?"
    new_vals = vals[1:] + [id_value]
    return postprocess(sql, new_vals)
